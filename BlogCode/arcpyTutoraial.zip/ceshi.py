# -*- coding:utf-8 -*-

import arcpy
print "hello world"