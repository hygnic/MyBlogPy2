# -*- coding:utf-8 -*-
# -------------------------------------------
# Name:              Code1
# Author:            Hygnic
# Created on:        2021/8/31 20:09
# Version:           
# Reference:         
"""
Description:         
Usage:               
"""
# -------------------------------------------
import arcpy
import os

arcpy.env.overwriteOutput = True
# lyr = os.path.abspath("../SHP/Boroughs.shp")
# print lyr
lyr = "../NYC.gdb/Boroughs"
lyr_no_prj = "../SHP/Boroughs_no_prj.shp"


desc = arcpy.Describe(lyr).spatialReference
name = arcpy.Describe(lyr).spatialReference.name
# rows = arcpy.da.SearchCursor("d:/base/data.gdb/buildings", ["SHAPE@"],  spatial_reference=desc.spatialReference)
# ss =  desc.spatialReference
print desc
