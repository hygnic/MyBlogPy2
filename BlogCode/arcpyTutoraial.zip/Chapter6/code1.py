# -*- coding:utf-8 -*-
# -------------------------------------------
# Name:              Code1
# Author:            Hygnic
# Created on:        2021/8/31 20:09
# Version:           
# Reference:         
"""
Description:         
Usage:               
"""
# -------------------------------------------
import arcpy
import os

arcpy.env.overwriteOutput = True
# lyr = os.path.abspath("../SHP/Boroughs.shp")
# print lyr
lyr = "../NYC.gdb/Boroughs"
lyr_no_prj = "../SHP/Boroughs_no_prj.shp"


desc = arcpy.Describe(lyr).spatialReference # 2263
name = arcpy.Describe(lyr).spatialReference.name
# rows = arcpy.da.SearchCursor("d:/base/data.gdb/buildings", ["SHAPE@"],  spatial_reference=desc.spatialReference)
# ss =  desc.spatialReference
sr = arcpy.SpatialReference(3857)
ss = sr.exportToString ()

print arcpy.CreateSpatialReference_management(3857)
# print name
print sr
# print ss
print desc.factoryCode

arcpy.DefineProjection_management(lyr_no_prj, 2263)
arcpy.ProjectRaster_management(lyr_no_prj, 2263)
arcpy.Project_management(lyr_no_prj, 2263)