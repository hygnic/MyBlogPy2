# -*- coding:utf-8 -*-
# -------------------------------------------
# Name:              Code1
# Author:            Hygnic
# Created on:        2021/8/31 20:09
# Version:           
# Reference:         
"""
Description:         
Usage:               
"""
# -------------------------------------------
import arcpy
import os

arcpy.env.overwriteOutput = True
wk = os.path.abspath("../SHP")
arcpy.env.workspace = wk

lyr = "../SHP/Boroughs.shp"
lyr_no_prj = "../SHP/Boroughs_no_prj.shp"




cf_m = arcpy.CreateFeatureclass_management
cf_m(wk, "blank", "Polygon", spatial_reference=2263)


sr = arcpy.SpatialReference(2263)
cf_m(wk, "blank", "Polygon", spatial_reference=sr)

prj_file = "../SHP/Boroughs.prj"
cf_m(wk, "blank", "Polygon", spatial_reference=prj_file)
