# -*- coding:utf-8 -*-
# -------------------------------------------
# Name:              Code1
# Author:            Hygnic
# Created on:        2021/8/31 20:09
# Version:           
# Reference:         
"""
Description:         
Usage:               
"""
# -------------------------------------------
import arcpy
import os

arcpy.env.overwriteOutput = True
lyr = "../Raster/N31E107.tif"


desc = arcpy.Describe(lyr).spatialReference
name = arcpy.Describe(lyr).spatialReference.name
sr = arcpy.SpatialReference(3857)
ss = sr.exportToString ()

print arcpy.CreateSpatialReference_management(3857)
# print name
print sr
# print ss
print desc.factoryCode
