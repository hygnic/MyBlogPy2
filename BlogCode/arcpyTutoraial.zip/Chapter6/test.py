# -*- coding:utf-8 -*-
# -------------------------------------------
# Name:              test
# Author:            Hygnic
# Created on:        2021/10/27 11:13
# Version:           
# Reference:         
"""
Description:         
Usage:               
"""
# -------------------------------------------
import arcpy

sr = arcpy.CreateSpatialReference_management(3857)
# print sr.name
print type(sr)

