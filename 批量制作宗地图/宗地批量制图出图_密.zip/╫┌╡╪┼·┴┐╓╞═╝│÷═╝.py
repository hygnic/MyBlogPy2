# -*- coding:utf-8 -*-
# ----------------------------------------------------------
# Author: LiaoChenchen
# Created on: 2021/1/29 17:34
# ----------------------------------------------------------
from __future__ import absolute_import
from __future__ import unicode_literals
from __future__ import print_function
from __future__ import division

import sys
from pprint import pprint
import arcpy
import os
from os.path import splitext as st
from os import listdir as ld


def createGDB(path, gdbname):
    """
    创建用于存放中间数据的GDB
    TODO 没有采用，直接用存放源数据的 GDB 即可
    :param path:
    :param gdbname:
    :return:
    """
    fullpath = os.path.join(path, gdbname)
    if arcpy.Exists(fullpath):
        arcpy.Delete_management(fullpath)
    arcpy.CreateFileGDB_management(path, gdbname)
    # arcpy.env.workspace = fullpath
    return fullpath
    

def select_template_size(size, template_size):
    """
    根据给出的size大小去 template_size 字典中匹配大小合适的模板，
    然后返回名称，如 pagesize1、2、3，如果没有合适的返回-1
    :param size:  宽和高组成的列表
        such as:[659.8490915000066, 822.3146429999917]
    :param template_size: 制图模板大小
    :return: 返回制图模板大小的名称（键），
        如果找不到适合的制图模板就返回 -1
    """
    map_w, map_h = size[0], size[1]
    map_div = map_w / map_h
    # 符合该制图单位的模板大小的字典
        # 字典推导式，生成如这样的字典：{... , "达州市" : (宽，高，面积大小，宽高比例)  , ...}。
        # ... v[0]>map_w and v[1]>map_h...  这段代码做了初步的筛选，筛选出满足该制图单位宽和高的 mxd模板。
        # 同时这里引入了 面积 和 宽高比例，这两个指标用于进一步的判断和筛选。
    template_size_fit = {
        k:(v[0], v[1], v[0]*v[1], v[0]/v[1]) for k,v
        in template_size.items() if v[0]>map_w and v[1]>map_h
    }
    # template_size_fit 将所有合适的模板尺寸转换为字典
        # {u'pagesize1': (183, 223, 40809, 0.820627802690583),
        #  u'pagesize2': (366, 446, 163236, 0.820627802690583),
        #  u'pagesize3': (915, 1115, 1020225, 0.820627802690583)}
    # pprint("template_size_fit")
    # pprint(template_size_fit)
    
    # 字典转列表
    d2l = zip(template_size_fit.keys(), template_size_fit.values())
    # 按元组中第三个数(面积)大小升序
    d2l = sorted(d2l, key=lambda x: x[1][2])
    # d2l
        # [(u'pagesize3', (915, 1115, 1020225, 0.820627802690583)),
        #  (u'pagesize2', (366, 446, 163236, 0.820627802690583)),
        #  (u'pagesize1', (183, 223, 40809, 0.820627802690583))]
    # pprint("d2l")
    # pprint(d2l)
    d_len = len(template_size_fit)
    # 在所有大小都满足的情况下，选择面积最小的最适合
    if d_len > 0:
        # two_remaind = d2l[:2]
        # (u'pagesize3', (1380, 850, 1173000, 1.6235294117647059))
        # res = min(two_remaind, key=lambda x: abs(x[1][3]-map_div))
        # return res[0] # u'pagesize3'
        return d2l[0][0]
    else:
        # info="存在超出页面大小的制图单位"
        return -1


def check_field(layer, field):
    """
    检查一个要素文件中是否存在field字段
    """
    fields = arcpy.ListFields(layer)
    return field in [_.name for _ in fields]


class PageSizeMatch(object):
    """
    适配页面大小
    """
    def __init__(self, feature_name, field, mxd_template):
        """
        :param feature_name: {String} # 制图索引图层的名字
        :param field: {String} field = "CITY" # 检索字段
        :param mxd_template: {String} 存放模板的路径
        """
        self.f = feature_name # 制图索引图层的名字
        self.field = field[0] # 仅用于索引的字段
        self.fields = field # 所有字段
        # self.m_d = mxd_template_d
        self.mxd_template = mxd_template
        self.minimum_bounding() # 制作最小几何边界图层
        true_height = self.check_width_height() # 获取真实的高度信息
        # 将高度信息更新入制图索引图层（MappingIndex）
        self.update_width_height(true_height)
        self.update_page_size()
    
    def minimum_bounding(self):
        """
        1.make MinimumBoundingGeometry feature layer
        2.add PAGRSIZE field
        :return:
        """

        mbe = arcpy.MinimumBoundingGeometry_management
        # 所有所有字段，保证生成的最小边界几何（索引图层）含有这些字段
        mbe(self.f, "m_out", "ENVELOPE", "LIST", self.fields, True)
        print("Complete MinimumBoundingGeometry")
        arcpy.Delete_management(self.f,"FeatureClass")
        arcpy.Rename_management("m_out",self.f,"FeatureClass")
        
        # 添加 PAGESIZE 字段
        if not check_field(self.f,"PAGESIZE"):
            # 没有计算过最小几何边界
            print('Add field PAGESIZE')
            arcpy.AddField_management(
                self.f, "PAGESIZE", "TEXT", field_length = 100)
    
    def check_width_height(self):
        # 使用 “要素折点转点要素” 工具，将最小边界几何转变成点；
        # 每一个最小边界几何都会生成5个点：左下，左上，右上，右下，左下；
        # 前两个点的差值就是高度
        # 返回值为高度的字典：{地级市名称：高度}
        # {..."广安市":879.2, "巴中市":124.56, "桂林市":54.7801, ...}
        fea_v = "feature_vertices" # feature name
        pprint("create feature vertices")
        short_f = arcpy.FeatureVerticesToPoints_management
        short_f(self.f, fea_v, "ALL")
        cursor = arcpy.da.SearchCursor(fea_v, [self.field, "SHAPE@Y"]) # "SHAPE@Y" 即要素的高（南北）
        cursor2l = [(x[0], x[1]) for x in cursor] # 转换成列表
        del cursor
        # [(u'\u5df4\u4e2d\u5e02', 3460475.693600001),
        # (u'\u5df4\u4e2d\u5e02', 3331847.4146)]
        # 每个矩形都会生成5个按顺序排列的点，cursor2l[::5] 使用切片每隔5个数取第一个；cursor2l[1::5] 使用切片每隔5个数取第二个。
        cursor2l_1 , cursor2l_2 = cursor2l[::5], cursor2l[1::5]
        height_info = {}
        # 这个 for 循环是将 y （南北方向）轴差值和制图单位名称组合成字典。
        for i in xrange(len(cursor2l_1)):
            height = cursor2l_2[i][1] - cursor2l_1[i][1]
            height_info[cursor2l_2[i][0]] = abs(height)
        arcpy.Delete_management(fea_v)
        pprint("Delete feature vertices")
        # 将制图单位名称（filed）和高组成字典，用于后续的比较。不能直接按顺序比较，比如带着制图单位名称去匹配，然后比较
        return height_info
    

    def update_width_height(self, height_infomation):
        """
        height_infomation 形参接收上面 check_width_height 方法的返回值。
        该方法会把 MappingIndex 图层中的 "MBG_Width","MBG_Length"两字段更新为宽和高
        :param height_infomation: {Dict} 包含了制图单位的高度信息
        :return:
        """
        _field = [self.field, "MBG_Width", "MBG_Length"]
        with arcpy.da.UpdateCursor(self.f, _field) as cursor:
            for row in cursor:
                name, width, height = row
                # 如果短边等于高度，字段 MBG_Width 和 MBG_Length 的意义从原来的短边和长边变成宽和高，
                # 那么原来 MBG_Width 和 MBG_Length 的值就需要互换。
                if round(height_infomation[name], 2) == round(width, 2):
                    row[1] = height
                    row[2] = width
                cursor.updateRow(row)
        pprint("update width and height value")
    
    
    # def update_page_size(self,scale):
    #     """
    #     更新填充字段 "PAGESIZE" 的值
    #     旧版方法，通过宽高比例来比较，
    #     其实完全可以根据制图比例加要素的宽高换算成实际的纸张尺寸。
    #     :param scale: {Int} 比例大小
    #     :return:
    #     """
    #     _field = ["MBG_Width", "MBG_Length", "PAGESIZE"]
    #     with arcpy.da.UpdateCursor(self.f, _field) as cursor:
    #         for row in cursor:
    #             row_p = [row[0], row[1]]
    #             #单位换算成了毫米 [659.8490915000066, 822.3146429999917]
    #             new_row = [x/scale*1000 for x in row_p]
    #             # PAGESIZE1 or -1
    #             pgs_name = select_template_size(new_row, self.m_d)
    #             if pgs_name != -1:
    #                 p_size = self.m_d[pgs_name] # (1180, 900)
    #                 # update PAGESIZE field values 1180x900
    #                 row[2] = "{}x{}".format(p_size[0],p_size[1])
    #             else:
    #                 print("存在超出所有模板页面大小的制图单位")
    #             cursor.updateRow(row)
    #     print("update PAGESIZE completly!")

    def size_creator(self):
        """
        根据输入的模板文件地址生成标准格式的字典。
        :return: {Dict} such as:
            {'pagesize3': (1180, 900),
            'pagesize2': (1080, 700),
            'pagesize1': (1080, 1300)}
        """
        pprint("请确保模板文件夹中不存在无关文件！")
        _m_dict = {}
        counter = 1
        for m_name in [st(x)[0] for x in ld(self.mxd_template) if ".mxd" or ".MXD" in x]:
            width, height = m_name.split("x")
            name = "pagesize{}".format(counter)
            _m_dict[name] = (int(width), int(height))
            counter += 1
        # {
        #     "pagesize1":(183,223),
        #     "pagesize2":(366,446),
        #     "pagesize3":(915,1115)
        # } #由于纸张是固定的A4尺寸，所以一定是高大些
        pprint(_m_dict)
        return _m_dict

    def update_page_size(self):
        """
        更新填充字段 "PAGESIZE" 的值
        :param scale: {Int} 比例大小
        :return:
        """
        _field = ["MBG_Width", "MBG_Length", "PAGESIZE"]
        with arcpy.da.UpdateCursor(self.f, _field) as cursor:
            for row in cursor:
                feature_size = [row[0], row[1]]
                # PAGESIZE1 or -1
                # sizes_d: 根据输入的模板文件地址生成的字典
                    # {
                    #     "pagesize1":(183,223),
                    #     "pagesize2":(366,446),
                    #     "pagesize3":(915,1115)
                    # }
                sizes_d = self.size_creator()
                pgs_name = select_template_size(feature_size, sizes_d)
                if pgs_name != -1:
                    p_size = sizes_d[pgs_name] # (1180, 900)
                    # update PAGESIZE field values 1180x900
                    row[2] = "{}x{}".format(p_size[0],p_size[1])
                else:
                    print("存在超出所有模板页面大小的制图单位")
                cursor.updateRow(row)
        print("update PAGESIZE completly!")



class MakeMXD(object):
    
    def __init__(self, m, lyrs, idx, query_field, scale=None):
        """
        :param m: {Object} MXD文件对象
        :param lyrs: {List} 需要设置定义查询语句图层的名称列表
        :param idx: {String} 索引图层名字；MappingIndex
        :param query_field: {String} 定义查询使用的字段名；比如 QSDWMC、CITY
        :param scale: {Int} 比例尺
        """
        self.mxd = m
        self.df = arcpy.mapping.ListDataFrames(self.mxd)[0]
        self.lyrs = lyrs
        self.field = query_field[0]
        self.fields = query_field
        self.scale = scale
        
        # MappingIndex
        self.mapidx = arcpy.mapping.ListLayers(self.mxd, idx)[0]
        
        self.mapping_index_query()
        self.make_mxd()
        del self.mxd
        del self.df
    
    def mapping_index_query(self):
        """
        给 MappingIndex 图层设置定义查询语句;
            PAGESIZE = '1080x700'
        :return:
        """
        map_path = self.mxd.filePath
        name = os.path.splitext(os.path.basename(map_path))[0]
        definition_query = ["PAGESIZE"," = ","'",name,"'"]
        self.size_name = name
        self.mapidx.definitionQuery = "".join(definition_query)
    
    def make_mxd(self):
        with arcpy.da.SearchCursor(self.mapidx, self.field) as cursor:
            for row in cursor:
                index_value = row[0]
                self.define_query(index_value) # 定义查询
                self.center_scale(index_value) # 居中
                self.buffer(index_value)
                self.change_txt(index_value) # 修改文本
                # self.label_query(index_value) # 标注查询语句
                # 取消该图层的所有选择选择项目 #TODO 或许每个图层都应该设置一次
                sba(self.mapidx, "CLEAR_SELECTION")
                self.saveacopy(index_value) # 另存
    
    def define_query(self, value):
        """
        定义查询，列表中的所有图层都设置定义查询
        :param value: {String/Int/Float} 用于定义查询的值
        :return: None
        """
        for layer in self.lyrs:
            lyr = arcpy.mapping.ListLayers(self.mxd, layer)[0]
            _expression = ['"',self.field,'"'," = ","'",value,"'"]
            lyr.definitionQuery = "".join(_expression)
            
        # 逆向定义查询 存在图层不显示符号，只显示标注，且不是主体要素的标注
        _expression_reverse = ['"',self.field,'"'," <> ","'",value,"'"]
        lyr = arcpy.mapping.ListLayers(self.mxd, self.lyrs[2])[0]
        lyr.definitionQuery = "".join(_expression_reverse)
    
    def center_scale(self, name):
        """
        使图框居中并设置比例尺
        :param name: {String/Int/Float} 用于查询语句的值
        :return: None
        """
        where_clause = "{} = '{}'".format(self.field, name)
        sba(self.mapidx, "NEW_SELECTION", where_clause)
        # self.df.extent = self.mapidx.getSelectedExtent()
        # 使用新 Extent 对象可平移和居中数据框，而无需更改数据框的比例
        self.df.panToExtent(self.mapidx.getSelectedExtent())
        # if self.scale:
        #     self.df.scale = self.scale
        # 将比例尺还原成默认比例尺，居中会改变比例尺大小
        # self.df.scale = df_scale
    
    def change_txt(self, index_value):
        # 修改文本
        cursor = arcpy.da.SearchCursor(self.mapidx, self.fields)
        # FIELD = ["宗地号" , "权利人", "宗地面积", "所在图幅号"]

        for row in cursor:
            field_0, field_1, field_2, field_3 = row
            if field_0 == index_value:
                zddm=field_0
                tdqlr=field_1
                zdmj=field_2
                sztfh=field_3
        for elm in arcpy.mapping.ListLayoutElements(
                self.mxd, 'TEXT_ELEMENT'):
            # 宗地代码
            if elm.name == "zddm":
                elm.text = zddm
            # 土地权利人：
            if elm.name == "tdqlr":
                elm.text = tdqlr
            # 宗地面积：
            if elm.name == "zdmj":
                elm.text = zdmj
            # 所在图幅号：
            if elm.name == "sztfh":
                # if len(sztfh) > 38:
                elm.text = sztfh
            # 单位
            if elm.name == "zrzyj":
                elm.text = dw
            # 制图日期
            if elm.name == "ztrq":
                elm.text = ztrq
            # 审核日期
            if elm.name == "shrq":
                elm.text = shrq
            # 制图员
            if elm.name == "zty":
                elm.text = zty
            # 审核员
            if elm.name == "shy":
                elm.text = shy
        del cursor
    
    def label_query(self,name):
        # 设置标注的查询语句
        lyr_label = arcpy.mapping.ListLayers(self.mxd, "市级区域")[0]
        if lyr_label.supports("LABELCLASSES"):
            # NOT( CITY = '巴中市' )
            query = ["NOT","( ", self.field, "=", "'", name, "'", " )"]
            for lblClass in lyr_label.labelClasses:
                lblClass.SQLQuery = "".join(query)
    
    def saveacopy(self, name):
        # 另存
        self.mxd.saveACopy(os.path.join(output_dir, name +'.mxd'), "10.1")
        print("Complete <name: {} size: {}> ".format(name, self.size_name))
        
    #_____________________________________________
    #_____________________________________________
    # 针对宗地图适配的图层处理操作：
    #     使用QSDW面图层（每个地图中间显示的主要区域）做一个外部的缓冲 10米；
    #     将缓冲区内的所有QSDW图层（面转线版本）裁剪下来；
    #     再使用缓冲区裁剪一个QSDW图层（原始面版本）用于标注；
    def buffer(self, value):
        """
        :param value: 每个图层的名称，用于给裁剪下来的线命名
        :return:
        """
        # 延长距离 缓冲区距离
        distans = int(self.df.scale)/300 #7000/100=70
        pprint("缓冲距离：{}米".format(distans))
        _buffrt_name = os.path.join(procedure_data, "buffer") # 默认覆盖
        if arcpy.Exists(_buffrt_name):
            arcpy.Delete_management(_buffrt_name)
        arcpy.analysis.Buffer(in_features = arcpy.mapping.ListLayers(self.mxd, self.lyrs[0])[0],
                              out_feature_class=_buffrt_name,
                              buffer_distance_or_field="{} Meters".format(str(distans)),
                              line_side="OUTSIDE_ONLY")
        # 生成缓冲区内的线
        _line_name = "L{}".format(value)
        _clipedline_name = os.path.join(procedure_data, _line_name) # 默认不覆盖
        # _clipedline_name = os.path.join(procedure_data, "v") # 默认不覆盖
        # 使用原始 gdb 里的QSDW宗地层_line数据，而不是mxd中的图层
        arcpy.analysis.Clip("QSDW宗地层_line", _buffrt_name, _clipedline_name)
        lyr = arcpy.mapping.ListLayers(self.mxd, "QSDW宗地层_line")[0]
        lyr.replaceDataSource(os.path.abspath(gdb_path), "FILEGDB_WORKSPACE", _line_name)
        
        
        # 生成缓冲区内的面，不显示，仅作为标注
        _polygon_name = "P{}".format(value)
        _clipedPolygon_name = os.path.join(procedure_data, _polygon_name) # 默认不覆盖
        arcpy.analysis.Clip("QSDW宗地层", _buffrt_name, _clipedPolygon_name)
        lyr = arcpy.mapping.ListLayers(self.mxd, "QSDW宗地层_label")[0]
        lyr.replaceDataSource(os.path.abspath(gdb_path), "FILEGDB_WORKSPACE", _polygon_name)
        arcpy.Delete_management(_buffrt_name)



if __name__ == '__main__':
    """_______global_values_______"""
    # 请在这里输入出图参数！
    mxd_template_f = "C:/Users/Administrator/Documents/MoveOn/MyBlogPy2/test/MXD101"  # 模板文件位置
    output_dir = "C:/Users/Administrator/Documents/MoveOn/MyBlogPy2/test/地图"  # 制图输出位置
    gdb_path = "C:/Users/Administrator/Documents/MoveOn/MyBlogPy2/test/test.gdb"  # 存放原始数据如宗地图、制图索引图层、DLTB的GDB数据库
    # 单位如 古蔺县自然资源局
    dw = "莱\n西\n市\n国\n土\n资\n源\n局"
    #制图日期
    ztrq = "2012年7月23日"
    #审核日期
    shrq = "2012年7月23日"
    # 制图员
    zty = "李泳才"
    #审核员
    shy = "郭复礼"
    
    # 重要常量
    # FIELD[0] 为检索字段，其余字段为为保证在生成的 MappingIndex 图层中含有相关字段，
    # 用于后续出图部分字体要素的替换
    FIELD = ["宗地号" , "权利人", "宗地面积", "所在图幅号"]
    Layer = ["QSDW宗地层","DLTB_标识后","QSDW宗地层_label"]
    
    MI = "MappingIndex" # 制图索引文件名称
    # SCALE = 200000 # 制图的比例尺
    """_______global_values_______"""
    
    arcpy.env.overwriteOutput = True
    arcpy.env.workspace =os.path.join(gdb_path, "Dataset")
    sba = arcpy.SelectLayerByAttribute_management
    # 创建存放中间数据的要素数据集
    arcpy.CreateFeatureDataset_management(gdb_path, "ProcedureData")
    procedure_data = os.path.join(gdb_path, "ProcedureData")
    
    pprint("重新运行请清空导出的图片！")
    pprint("开始处理......")


    # 模板匹配
    PageSizeMatch(MI, FIELD, mxd_template_f)

    # 自动制图(MXD)
    for a_mxd in [x for x in os.listdir(mxd_template_f)
                  if ".mxd" or ".MXD" in x]:
        pprint(a_mxd)
        mxd_fullpath = os.path.join(mxd_template_f, a_mxd)
        mxd = arcpy.mapping.MapDocument(mxd_fullpath)

        MakeMXD(
            mxd,
            Layer,
            MI, FIELD)

    # 地图导出(JPG)
    pprint("starting export map")
    for a_mxd in [x for x in os.listdir(output_dir)
                  if ".mxd" or ".MXD" in x]:
        mxd_fullpath = os.path.join(output_dir, a_mxd)
        mxd = arcpy.mapping.MapDocument(mxd_fullpath)
        export_paht = os.path.join(output_dir,a_mxd)
        arcpy.mapping.ExportToJPEG(mxd, export_paht, resolution=300)
        pprint(export_paht)
